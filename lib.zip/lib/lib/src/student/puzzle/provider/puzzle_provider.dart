import 'package:flutter/cupertino.dart';


class PuzzleProvider extends ChangeNotifier {


}