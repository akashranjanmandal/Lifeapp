import 'package:flutter/cupertino.dart';

class SubjectListProvider extends ChangeNotifier {

}